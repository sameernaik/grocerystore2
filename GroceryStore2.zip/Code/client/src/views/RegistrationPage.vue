<template>
    <RegistrationForm></RegistrationForm>
</template>

<script>
/*import NavBar from '@/layouts/NavBar.vue'*/
import RegistrationForm from '@/components/RegistrationForm.vue'


export default {
  name: 'App',
  components: {
    /*NavBar,*/
    RegistrationForm
  }
}
</script>