<template>
    Home Page
    
</template>

<script>
/*import NavBar from '@/layouts/NavBar.vue'*/
//import HelloWorld from '@/components/HelloWorld.vue'


export default {
  name: 'App',
  components: {
    /*NavBar,*/
    
  }
}
</script>