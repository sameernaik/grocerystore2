<template>
    <LoginForm></LoginForm>
</template>

<script>
/*import NavBar from '@/layouts/NavBar.vue'*/
import LoginForm from '@/components/LoginForm.vue'


export default {
  name: 'App',
  components: {
    /*NavBar,*/
    LoginForm
  }
}
</script>