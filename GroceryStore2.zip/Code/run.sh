#!/bin/bash
chmod +x client.sh
chmod +x server.sh

open -a Terminal.app ./server.sh
open -a Terminal.app ./client.sh


